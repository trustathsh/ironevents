package de.hshannover.f4.trust.ironevents;

public class Ironevents {

	public static void main(String[] args) {
		System.out.println("This project only holds the data of events emitted by iron projects. \n "
				+ "It currently has no function!");		

	}

}
