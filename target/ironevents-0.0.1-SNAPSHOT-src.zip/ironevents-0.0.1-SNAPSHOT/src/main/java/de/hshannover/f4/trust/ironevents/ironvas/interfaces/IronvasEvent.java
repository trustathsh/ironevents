package de.hshannover.f4.trust.ironevents.ironvas.interfaces;

import java.sql.Timestamp;
import java.util.UUID;

public interface IronvasEvent {

	public UUID getUuid();

	public String getBid();

	public float getCvssbase();

	public String getDescription();

	public String getHost();

	public String getPublisherId();

	public String getName();

	public Boolean getNewEventFlag();

	public String getNvtOid();

	public String getPort();

	public String getResultId();

	public String getRiskFactor();

	public String getSubnet();

	public String getThreat();

	public String getCve();

	public Timestamp getDetectTimestamp();

	public Timestamp getCreateTimestamp();

}