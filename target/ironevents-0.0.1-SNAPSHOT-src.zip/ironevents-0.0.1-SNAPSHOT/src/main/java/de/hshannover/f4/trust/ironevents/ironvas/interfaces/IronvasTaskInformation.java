package de.hshannover.f4.trust.ironevents.ironvas.interfaces;


/**
 * 
 * Informations for the vulnerability scanner to perform a network scan or 
 * to delete the informations about a previously performed scan
 *  
 * **/

public interface IronvasTaskInformation {
	
	public String getIP();
	
	public String getNamePrefix();
	
	public long getTimestamp();
	
}
