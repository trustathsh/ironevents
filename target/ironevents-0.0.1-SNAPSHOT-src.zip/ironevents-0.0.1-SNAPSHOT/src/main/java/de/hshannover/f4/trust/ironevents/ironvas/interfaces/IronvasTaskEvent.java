package de.hshannover.f4.trust.ironevents.ironvas.interfaces;

public interface IronvasTaskEvent {

}
