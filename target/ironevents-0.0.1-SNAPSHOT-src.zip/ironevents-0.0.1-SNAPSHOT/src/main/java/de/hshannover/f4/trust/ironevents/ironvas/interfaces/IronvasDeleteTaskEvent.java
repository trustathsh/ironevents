package de.hshannover.f4.trust.ironevents.ironvas.interfaces;

import java.util.List;

public interface IronvasDeleteTaskEvent extends IronvasTaskEvent{

	public List<IronvasTaskInformation> getTaskInfos();
	
}
