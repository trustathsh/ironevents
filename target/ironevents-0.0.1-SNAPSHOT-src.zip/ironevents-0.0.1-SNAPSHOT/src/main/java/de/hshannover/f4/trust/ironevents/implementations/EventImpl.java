package de.hshannover.f4.trust.ironevents.implementations;

import java.sql.Timestamp;
import java.util.UUID;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.uuid.EthernetAddress;
import com.fasterxml.uuid.Generators;

import de.hshannover.f4.trust.ironevents.interfaces.Event;



public abstract class EventImpl implements Event{

	
    /**
	 * 
	 */
	private static final long serialVersionUID = 7759460696662713652L;
	
    @JsonProperty("ui")
    protected final UUID uuid;

	@JsonProperty("ct")
    protected final Timestamp createTime;

    @JsonProperty("dt")
    protected final Timestamp detectTime;

    protected EventImpl(Timestamp createTime, Timestamp detectTime) {
    	
    	this.createTime = createTime;
    	this.detectTime = detectTime;
    	
        this.uuid = Generators.timeBasedGenerator(EthernetAddress.fromInterface()).generate();
    }
    
    public Timestamp getCreateTime() {
		return createTime;
	}

	public Timestamp getDetectTime() {
		return detectTime;
	}   	
	
}
