/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package de.hshannover.f4.trust.ironevents.interfaces;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.UUID;

/**
 * Marker interface. Every Event interface MUST extend this one.
 *
 * @author Marius Rohde
 */
public interface Event extends Serializable {

    public UUID getUuid(); // An unique id for every event

    public Timestamp getDetectTimestamp(); // The timestamp of an event detected by third party tool if existent else the same timestamp as create

    public Timestamp getCreateTimestamp(); // The timestamp of an event when it is instantiated

}
