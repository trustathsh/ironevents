package de.hshannover.f4.trust.ironevents.ironvas.interfaces;


public interface IronvasScanTaskEvent extends IronvasTaskEvent{
	
	public IronvasTaskInformation getInfo();

	public String getConfigName();
}
